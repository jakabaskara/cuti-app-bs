<?php

namespace App\Livewire;

use Livewire\Component;

class AsistenTabelPengajuanCuti extends Component
{
    public function render()
    {
        return view('livewire.asisten-tabel-pengajuan-cuti');
    }
}
