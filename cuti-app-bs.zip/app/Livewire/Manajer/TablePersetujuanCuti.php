<?php

namespace App\Livewire\Manajer;

use Livewire\Component;

class TablePersetujuanCuti extends Component
{
    public function render()
    {
        return view('livewire.manajer.table-persetujuan-cuti');
    }
}
