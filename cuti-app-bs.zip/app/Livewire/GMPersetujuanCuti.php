<?php

namespace App\Livewire;

use Livewire\Component;

class GMPersetujuanCuti extends Component
{

    public $permintaanCutis;


    public function render()
    {
        return view('livewire.g-m-persetujuan-cuti');
    }
}
