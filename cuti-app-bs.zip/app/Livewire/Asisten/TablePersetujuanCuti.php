<?php

namespace App\Livewire\Asisten;

use Livewire\Component;

class TablePersetujuanCuti extends Component
{
    public function render()
    {
        return view('livewire.asisten.table-persetujuan-cuti');
    }
}
