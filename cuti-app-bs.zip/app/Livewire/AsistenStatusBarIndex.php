<?php

namespace App\Livewire;

use Livewire\Component;

class AsistenStatusBarIndex extends Component
{
    public function render()
    {
        return view('livewire.asisten-status-bar-index');
    }
}
